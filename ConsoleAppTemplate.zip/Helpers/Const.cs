﻿namespace $safeprojectname$.Helpers
{
    public class Const
    {
        
    }
}