﻿namespace $safeprojectname$.Helpers
{
    public class AppSettings
    {
        
    }
}