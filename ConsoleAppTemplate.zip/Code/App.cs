﻿using System;
using System.Threading.Tasks;
using $safeprojectname$.Abstractions;
using Microsoft.Extensions.Logging;

namespace $safeprojectname$.Code
{
    public class App: IRun
    {
        private readonly ILogger<App> _logger;

        public App(ILogger<App> logger)
        {
            _logger = logger;
        }

        public async Task Run()
        {
            try
            {

            }
            catch (Exception e)
            {
                _logger.LogCritical($"{e.Message}\r\n{e.StackTrace}");
            }
        }
    }
}