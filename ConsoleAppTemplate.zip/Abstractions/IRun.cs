﻿using System.Threading.Tasks;

namespace $safeprojectname$.Abstractions
{
    public interface IRun
    {
        Task Run();
    }
}